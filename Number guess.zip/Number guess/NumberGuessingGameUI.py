import tkinter as tk
from tkinter import messagebox
from backend import NumberGuessingGame
import os
from PIL import Image,  ImageTk
from tkinter import ttk

# class StartgameUI:
#     def __init__(self,) -> None:
#             self.win = tk. Tk()
#             self.win.geometry("1100x700")
#             image1 = Image. open("guessgame.jpeg")
#             image2 =  ImageTk. PhotoImage(image1)
#             image_label = ttk. Label(self.win , image =image2)
#             image_label.place(x = 0 , y = 0)
#             register_button = tk.Button(self.win, text="Register",width=15, height=3,command=self.destroywindow())
#             register_button.place(x=500,y=500)
#             self.win.mainloop()
#     def destroywindow(self):
        # login_gui = NumberGuessingGameGUI()
        # login_gui.window.mainloop()

class NumberGuessingGameGUI:
    def __init__(self):
        self.game = NumberGuessingGame()


        self.window = tk.Tk()
        self.window.geometry("1100x600")
        self.window.configure(background='light blue')
        self.window.title("Number Guessing Game")

        self.username_label = tk.Label(self.window, text="Username:",width=15, height=2,font=('Times New Roman', 15, 'bold'))
        self.username_label.place(x=500,y=50)

        self.username_entry = tk.Entry(self.window,width=30,borderwidth=5,border=3)
        self.username_entry.place(x=500,y=130)

        self.password_label = tk.Label(self.window, text="Password:",width=15, height=2,font=('Times New Roman', 15, 'bold'))
        self.password_label.place(x=500,y=210)

        self.password_entry = tk.Entry(self.window, show="*",width=30,border=5)
        self.password_entry.place(x=500,y=290)

        self.login_button = tk.Button(self.window, text="Login",width=15, height=2,font=('Times New Roman', 15, 'bold'), command=self.login)
        self.login_button.place(x=500,y=350)

        self.register_button = tk.Button(self.window, text="Register",width=15, height=2,font=('Times New Roman', 15, 'bold'), command=self.show_registration)
        self.register_button.place(x=500,y=440)

        self.registration_window = None

    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        # Perform validation
        if self.validate_credentials(username, password):
            self.start_game()
        else:
            messagebox.showerror("Login Failed", "Invalid username or password!")

    def validate_credentials(self, username, password):
        if not os.path.isfile("credentials.txt"):
            with open("credentials.txt", "w") as file:
                pass  # Create an empty file if it doesn't exist

        with open("credentials.txt", "r") as file:
            for line in file:
                stored_username, stored_password = line.strip().split(",")
                if username == stored_username and password == stored_password:
                    return True
        return False

    def show_registration(self):
        if self.registration_window is not None:
            self.registration_window.destroy()

        self.registration_window = tk.Toplevel(self.window)
        self.registration_window.title("Registration")
        self.registration_window.configure(background='light blue')

        self.reg_username_label = tk.Label(self.registration_window, text="Username:",width=15, height=2,font=('Times New Roman', 15, 'bold'))
        self.reg_username_label.pack(pady=10)

        self.reg_username_entry = tk.Entry(self.registration_window,width=30,borderwidth=5,border=3)
        self.reg_username_entry.pack(pady=30)

        self.reg_password_label = tk.Label(self.registration_window, text="Password:",width=15, height=2,font=('Times New Roman', 15, 'bold'))
        self.reg_password_label.pack(pady=10)

        self.reg_password_entry = tk.Entry(self.registration_window, show="*",width=30,borderwidth=5,border=3)
        self.reg_password_entry.pack(pady=30)

        self.register_button = tk.Button(self.registration_window, text="Register",width=15, height=2,font=('Times New Roman', 15, 'bold'), command=self.register)
        self.register_button.pack(pady=30)

    def register(self):
        username = self.reg_username_entry.get()
        password = self.reg_password_entry.get()

        # Perform registration
        if self.validate_credentials(username, password):
            messagebox.showwarning("Registration Failed", "Username already exists!")
        else:
            with open("credentials.txt", "a") as file:
                file.write(f"{username},{password}\n")
            messagebox.showinfo("Registration Successful", "You have been registered successfully!")
            self.registration_window.destroy()

    def start_game(self):
    # Get the entered username and password
        username = self.username_entry.get()
        password = self.password_entry.get()

        # Validate the username
        if not self.validate_username(username):
            messagebox.showerror("Invalid Username", "Please enter a valid username!")
            return

        # Validate the credentials and start the game
        if self.validate_credentials(username, password):
            self.window.destroy()  # Close the login window

            # Execute the file containing the game UI
            # os.system("python number_guessing_game_ui.py")
        else:
            messagebox.showerror("Login Failed", "Invalid username or password!")

    def validate_username(self, username):
        # Perform any necessary validation for the username
        if not username or len(username.strip()) == 0:
            return False
        return True


class NumberGuessingGameUI:
    def __init__(self):
        self.game = NumberGuessingGame()

    def run(self):
        root = tk.Tk()
        root.title("Number Guessing Game")
        root.geometry("1100x600")
        root.configure(background='light blue')

        self.label = tk.Label(root, text="Welcome to the Number Guessing Game!",font=('Times New Roman', 15, 'bold'))
        self.label.place(x=410,y=10)

        self.name_label = tk.Label(root, text="Enter your name:",font=('Times New Roman', 15, 'bold'))
        self.name_label.place(x=500,y=50)

        self.name_entry = tk.Entry(root,width=30,borderwidth=5,border=3)
        self.name_entry.place(x=500,y=100)

        self.start_button = tk.Button(root, text="Start Game",width=15,font=('Times New Roman', 15, 'bold') ,command=self.start_game)
        self.start_button.place(x=500,y=150)

        self.guess_label = tk.Label(root, text="Enter your guess (1-50):",font=('Times New Roman', 15, 'bold'))
        self.guess_label.place(x=500,y=200)
        self.guess_entry = tk.Entry(root, width=30,borderwidth=5,border=3,state=tk.DISABLED)
        self.guess_entry.place(x=500,y=250)

        self.guess_button = tk.Button(root, text="Guess",width=15, command=self.guess_number, state=tk.DISABLED,font=('Times New Roman', 15, 'bold'))
        self.guess_button.place(x=500,y=280)
        self.high_scores_label = tk.Label(root, text="Scores:",font=('Times New Roman', 15, 'bold'))
        self.high_scores_label.place(x=500,y=320)

        self.high_scores_list = tk.Listbox(root,width=18,borderwidth=5,border=3,height=6,font=('Times New Roman', 15, 'bold'))
        self.high_scores_list.place(x=500,y=350)

        self.quit_button = tk.Button(root,width=15 ,text="Quit",font=('Times New Roman', 15, 'bold'), command=root.quit)
        self.quit_button.place(x=500,y=500)
        root.mainloop()

    def start_game(self):
        self.game.start_game(self.name_entry.get())
        self.label.config(text=f"Welcome to the Number Guessing Game, {self.game.player_name}! You have {self.game.max_guesses} guesses to guess the number between 1 and 50.")
        self.guess_entry.config(state=tk.NORMAL)
        self.guess_button.config(state=tk.NORMAL)

    def guess_number(self):
        if self.game.game_over:
            self.save_high_score()
            self.update_high_scores()
            self.guess_entry.config(state=tk.DISABLED)
            self.guess_button.config(state=tk.DISABLED)
        else:
            guess = self.guess_entry.get()
            result = self.game.guess_number(int(guess))
            self.label.config(text=result)
            self.guess_entry.config(state=tk.NORMAL)
            self.guess_button.config(state=tk.NORMAL)
        

    def update_high_scores(self):
        filename = "high_scores.txt"
        with open(filename, "r") as f:
            for line in f:
                self.high_scores_list.insert(tk.END,line)

    def save_high_score(self):
        filename = "high_scores.txt"
        high_scores = self.game.get_high_scores()
        with open(filename, "a") as f:
            f.write(high_scores[0] + " " + str(high_scores[1]) + "\n")


# Create an instance of the GUI and run it

# strgm=StartgameUI()
# # login_gui.window.mainloop()
login_gui = NumberGuessingGameGUI()
login_gui.window.mainloop()

# Only start the game UI if the login was successful
if login_gui.start_game:
    game_ui = NumberGuessingGameUI()
    game_ui.run()
